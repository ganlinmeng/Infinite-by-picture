//
//  AppDelegate.h
//  图片轮播器WuXIanXunHuan
//
//  Created by 成 on 16/4/15.
//  Copyright © 2016年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

